let kelimeler = [
    "javascript",
    "bilgisayar",
    "programlama",
    "internet",
    "teknoloji",
    "oyun",
    "yazilim",
    "algoritma"
];

let secilenKelime = "";
let gorunenKelime = [];
let can = 9999;

function yeniOyun() {

    secilenKelime = kelimeler[Math.floor(Math.random() * kelimeler.length)];
    console.log(secilenKelime);

    gorunenKelime = [];

    for (let i = 0; i < secilenKelime.length; i++) {
        gorunenKelime.push("_");
    }

    can = 6;

    document.getElementById("can").textContent = can;

    goster();

    document.getElementById("mesaj").textContent = "";
}

function goster() {
    document.getElementById("kelime").textContent = gorunenKelime.join(" ");
}

function tahminEt() {

    let harf = document.getElementById("harf").value.toLowerCase();
    document.getElementById("harf").value = "";

    let dogru = false;

    for (let i = 0; i < secilenKelime.length; i++) {

        if (secilenKelime[i] === harf) {

            gorunenKelime[i] = harf;
            dogru = true;

        }

    }

    if (!dogru) {

        can--;
        document.getElementById("can").textContent = can;

    }

    goster();

    if (!gorunenKelime.includes("_")) {

        document.getElementById("mesaj").textContent = "Kazandın 🎉";

    }

    if (can === 0) {

        document.getElementById("mesaj").textContent = "Kaybettin! Kelime: " + secilenKelime;

    }

}

yeniOyun();