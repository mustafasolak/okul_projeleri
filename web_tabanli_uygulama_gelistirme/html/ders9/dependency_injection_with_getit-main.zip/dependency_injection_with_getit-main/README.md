# dependency_injection_with_getit
 Dependency Injection with get_it
