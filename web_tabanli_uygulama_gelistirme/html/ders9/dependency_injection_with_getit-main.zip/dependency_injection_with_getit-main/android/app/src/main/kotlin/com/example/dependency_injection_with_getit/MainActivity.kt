package com.example.dependency_injection_with_getit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
